using System;

namespace Roc.WCCOA
{
	//------------------------------------------------------------------------------------------------------------------------
	public static class WCCOAProxyServer 
	{
		public static WCCOAProxy proxy;
	}

}

